// Voice profile photos
import mario from './mario.png'
import juanCarlos from './juan carlos.png'
import joseMiguel from './Jose Miguel.png'
import francisca from './francisca.png'
import titi from './titi.png'

export const voicePhotos: Record<string, string> = {
  'mario': mario,
  'juan carlos': juanCarlos,
  'jose miguel': joseMiguel,
  'francisca': francisca,
  'titi': titi,
}
