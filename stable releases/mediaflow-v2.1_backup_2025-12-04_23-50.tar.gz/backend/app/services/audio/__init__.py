"""
Audio processing services
"""
from app.services.audio.jingle import jingle_service

__all__ = ["jingle_service"]
